package com.example.exchangerates.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.exchangerates.R
import com.example.exchangerates.business.*
import com.example.exchangerates.databinding.FragmentFavoritesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FavoritesFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View {
        val binding = FragmentFavoritesBinding.inflate(inflater, container, false)
        binding.rv2.layoutManager = LinearLayoutManager(context)
        var size = 0
        for (i in 0..24)
            if (WebHelper.data[i][4] == R.drawable.star_on.toString())
                size++
        val data2 = Array(size) { Array(5) { "-" } }
        size = 0
        for (i in 0 until WebHelper.data.size)
            if (WebHelper.data[i][4] == R.drawable.star_on.toString())
                data2[size++] = WebHelper.data[i]
        binding.rv2.adapter = RecyclerAdapter(data2)
        return binding.root
    }

    override fun onDestroyView() {
         val bookDao = Room.databaseBuilder(requireContext(), SavesDatabase::class.java,
            "saves_database" ).build().savesDao()
        GlobalScope.launch(Dispatchers.IO) {
            for (i in 0..24) bookDao.update( Saves(i, "" + WebHelper.data[i][4]) )
        }
        super.onDestroyView()
    }
}