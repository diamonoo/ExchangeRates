package com.example.exchangerates.business

import androidx.room.*

@Dao
interface SavesDao {
    @Insert
    suspend fun insertBook(save: Saves)

    @Query("SELECT * FROM saves_table")
    fun getAll(): List<Saves>

    @Update
    suspend fun update(save: Saves)

    @Delete
    suspend fun delete(save: Saves)

    @Query("DELETE FROM saves_table")
    fun deleteAll()
}