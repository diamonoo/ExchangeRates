package com.example.exchangerates.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.exchangerates.business.*
import com.example.exchangerates.databinding.FragmentHomeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val binding = FragmentHomeBinding.inflate(inflater, container, false)
        binding.rv.layoutManager = LinearLayoutManager(context)
        if (WebHelper.isFirstLaunch) {
            GlobalScope.launch(Dispatchers.IO) {
                WebHelper.isDone = false
                DBHelper.isDone = false
                WebHelper.getHtmlFromWeb()
                val bookDao = Room.databaseBuilder(requireContext(), SavesDatabase::class.java,
                    "saves_database" ).build().savesDao()
                DBHelper.fill(bookDao)
            }
            while (WebHelper.isDone == false || DBHelper.isDone == false) Thread.sleep(30)
            WebHelper.isFirstLaunch = false
        }
        binding.rv.adapter = RecyclerAdapter(WebHelper.data)
        return binding.root
    }

    override fun onDestroyView() {
        GlobalScope.launch(Dispatchers.IO) {
            val bookDao = Room.databaseBuilder(requireContext(), SavesDatabase::class.java,
                "saves_database").build().savesDao()
            for (i in 0 until WebHelper.data.size)
                bookDao.update(Saves(i, "" + WebHelper.data[i][4]))
        }
        super.onDestroyView()
    }
}