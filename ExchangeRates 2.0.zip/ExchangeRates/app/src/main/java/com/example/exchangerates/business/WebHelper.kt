package com.example.exchangerates.business

class WebHelper {
    companion object {
        var data = Array(25) { Array(5) { "-" } }
        var isFirstLaunch = true
        var isDone = false

        fun getHtmlFromWeb() {
            try {
                val el = org.jsoup.Jsoup.connect("https://myfin.by/bank/kursy_valjut_nbrb")
                    .get()
                    .getElementsByClass("default-table")
                    .select("tbody > tr")
                for (i in 0 until el.size) {
                    val td = el[i].select("td")
                    data[i][0] = td[0].text()
                    data[i][1] = td[1].text()
                    data[i][2] = td[td.size - 2].text()
                    data[i][3] = td[td.size - 1].text()
                }
            } catch (_: java.io.IOException) {}
            isDone = true
        }
    }
}