package com.example.exchangerates.business

import com.example.exchangerates.R
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DBHelper {
    companion object {
        var isDone = false

        @OptIn(DelicateCoroutinesApi::class)
        fun fill(savesDao: SavesDao) {
            GlobalScope.launch(Dispatchers.IO) {
                var books = savesDao.getAll()
                if (books.isEmpty()) {
                    for (i in 0..24) {
                        savesDao.insertBook(Saves(i, "" + R.drawable.star_off.toString()))
                        books = savesDao.getAll()
                    }
                }
                for (i in books.indices) WebHelper.data[i][4] = books[i].value
                isDone = true
            }
        }
    }
}