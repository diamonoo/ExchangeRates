package com.example.exchangerates.business

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.exchangerates.R
import com.google.android.material.floatingactionbutton.FloatingActionButton

class RecyclerAdapter(private val names: Array<Array<String>>) :
    RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>() {
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tv1: TextView = itemView.findViewById(R.id.tv1)
        val tv2: TextView = itemView.findViewById(R.id.tv2)
        val tv3: TextView = itemView.findViewById(R.id.tv3)
        val tv4: TextView = itemView.findViewById(R.id.tv4)
        val fab: FloatingActionButton = itemView.findViewById(R.id.fab)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder =
        MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false))

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.tv1.text = names[position][0]
        holder.tv2.text = names[position][1]
        holder.tv3.text = names[position][2]
        holder.tv4.text = names[position][3]
        holder.fab.setImageResource(names[position][4].toInt())

        holder.fab.setOnClickListener {
            if (names[position][4] == R.drawable.star_off.toString())
                names[position][4] = R.drawable.star_on.toString()
            else
                names[position][4] = R.drawable.star_off.toString()
            holder.fab.setImageResource(names[position][4].toInt())
        }
    }

    override fun getItemCount() = names.size
}