package com.example.exchangerates.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.exchangerates.business.WebHelper
import com.example.exchangerates.databinding.FragmentConverterBinding

class ConverterFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentConverterBinding.inflate(inflater, container, false)
        binding.fab2.setOnClickListener {
            val data = WebHelper.data
            if (binding.et.text.isNotEmpty())
                binding.tvres.text = String.format("%.4f",
                    data[binding.spinner1.selectedItemPosition][1].toDouble()
                            / data[binding.spinner1.selectedItemPosition][3].toDouble()
                            * binding.et.text.toString().toDouble()
                            / data[binding.spinner2.selectedItemPosition][1].toDouble()
                            * data[binding.spinner2.selectedItemPosition][3].toDouble()
                )
            else binding.tvres.text = "0"
        }
        return binding.root
    }
}