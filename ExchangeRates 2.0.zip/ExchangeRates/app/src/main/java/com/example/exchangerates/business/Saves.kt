package com.example.exchangerates.business

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saves_table")
data class Saves(
    @PrimaryKey(autoGenerate = false)
    var id: Int,
    var value: String
)
